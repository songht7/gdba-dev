微信官方 js-sdk
----

说明: 仅将官方 js-sdk 发布到 npm，支持 CommonJS，便于 browserify, webpack 等直接使用

js源码: https://res.wx.qq.com/open/js/jweixin-1.6.0.js

官方使用说明: https://mp.weixin.qq.com/wiki?t=resource/res_main&id=mp1421141115

安装:
    
    npm install weixin-js-sdk
    
使用:
    
    var wx = require('weixin-js-sdk');

### Old versions

* [1.0.0](https://github.com/yanxi-me/weixin-js-sdk/tree/1.0.0)
* [1.2.0](https://github.com/yanxi-me/weixin-js-sdk/tree/1.2.0)
